//package jp.co.bbreak.sokusen._4._3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WriteCsv2 {

	public static void main(String[] args) {

		// 출력 스트림 오브젝트 생성 
		BufferedWriter bufWriter = null;
		try {
			bufWriter = Files.newBufferedWriter(
					Paths.get("outputCSV.csv"),
					Charset.forName("UTF-8"));

			// CSV 파일 읽기
			List<List<String>> allData = readCSV();

			for (List<String> newLine : allData) {

				// １행분 데이터
				List<String> list = newLine;

				for (String data : list) {

					bufWriter.write(data);
					bufWriter.write(",");
				}

				// 추가할 주소 데이터
				bufWriter.write("주소");

				// 개행 코드 추가 
				bufWriter.newLine();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bufWriter != null) {
					bufWriter.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * CSV 파일을 읽어 들이는 클래스
	 *
	 */
	public static List<List<String>> readCSV() {

		// 반환용 리스트 변수 
		List<List<String>> ret = new ArrayList<List<String>>();

		// 입력 스트림 오브젝트 생성 
		BufferedReader bufread = null;

		try {
			// 대상 CSV 파일 경로 설정 
			bufread = Files.newBufferedReader(
					Paths.get("Sample.csv"),
					Charset.forName("UTF-8"));

			// CSV 파일에서 읽어 들인 1행분 데이터
			String line = "";

			while ((line = bufread.readLine()) != null) {

				// CSV 파일의 1행을 저장하는 리스트 변수
				List<String> tmpList = new ArrayList<String>();

				String revise = "경리부";
				Pattern p = Pattern.compile(revise);

				Matcher m = p.matcher(line);
				line = m.replaceAll("총무부");

				String array[] = line.split(",");

				// 배열에서 리스트로 변환
				tmpList = Arrays.asList(array);

				// 반환용 리스트 1행 데이터 저장 
				ret.add(tmpList);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bufread != null) {
					bufread.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return ret;
	}
}
