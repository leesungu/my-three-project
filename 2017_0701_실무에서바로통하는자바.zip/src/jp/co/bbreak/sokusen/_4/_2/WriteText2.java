package jp.co.bbreak.sokusen._4._2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WriteText2 {

	public static void main(String[] args) {

		try {
			// 출력 파일의 File 오브젝트 생성 
			File file = new File("c:\\sokusen\\sampleWrite2.txt");

			// 파일이 쓰기 가능한지 체크
			if (file.isFile() && file.canWrite()) {

				BufferedWriter bufwriter = new BufferedWriter(new FileWriter(
						file));
				// 문자열 쓰기
				bufwriter.write("문자열 추가１");
				// 개행 코드 추가 
				bufwriter.newLine();

				// 문자열 쓰기 
				bufwriter.write("문자열 추가2");
				// 개행 코드 추가 
				bufwriter.newLine();

				// bufwriter 오브젝트 닫기
				bufwriter.close();
			}

		} catch (IOException e) {
			System.out.println(e);
		}

	}

}
