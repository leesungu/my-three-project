package jp.co.bbreak.sokusen._4._5;

import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

public class OutputConsoleLog {
	public static void main(String[] args) {

		// INFO 레벨 설정 
		Logger.getGlobal().setLevel(Level.INFO);

		Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

		// 로그 출력 방식 설정
		logger.addHandler(new ConsoleHandler() {
			{
				setOutputStream(System.out);
				setLevel(Level.INFO);
			}
		});

		Logger.getGlobal().severe("로그레벨：severe");
		Logger.getGlobal().warning("로그레벨：warning");
		Logger.getGlobal().info("로그레벨：info");
		Logger.getGlobal().config("로그레벨：config");
		Logger.getGlobal().fine("로그레벨：fine");
		Logger.getGlobal().finer("로그레벨：finer");
		Logger.getGlobal().finest("로그레벨：finest");
	}
}
