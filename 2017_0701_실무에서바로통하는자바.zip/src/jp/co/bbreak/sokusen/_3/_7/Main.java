package jp.co.bbreak.sokusen._3._7;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		SampleDAO dao = new SampleDAO();
		
		// 데이터베이스 액세스 
		ArrayList<SampleDTO> books = dao.findAll();
		
		// 결과 표시 
		for(SampleDTO book : books) {
			System.out.println("id:" + book.getId());
			System.out.println("name:" + book.getName());
			System.out.println("price:" + book.getPrice());
		}
	}
}