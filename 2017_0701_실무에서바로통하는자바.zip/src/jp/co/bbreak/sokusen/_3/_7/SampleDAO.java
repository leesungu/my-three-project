package jp.co.bbreak.sokusen._3._7;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class SampleDAO {
	public ArrayList<SampleDTO> findAll() {
		// DTO를 저장하는 리스트
		ArrayList<SampleDTO> sampleDTOs = new ArrayList<>();

		// JDBC 드라이버 로딩
		try {
			// postgreSQL의 JDBC 드라이버 로딩
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			// JDBC 드라이버를 찾지 못한 경우
			e.printStackTrace();
		}

		// 1.데이터베이스 접속
		try(Connection conn = DriverManager.getConnection("jdbc:postgresql:javasample", "postgres", "password");) {
			// 2.SELECT문 발행
			// Statement 오브젝트 생성 
			Statement stmt = conn.createStatement();
			// SELECT문을 발행하고 검색 결과를 저장한다
			ResultSet rset = stmt.executeQuery("SELECT * FROM book");

			// 3.결과를 DTO에 저장한다
			while (rset.next()) {
				// DTO 오브젝트 생성
				SampleDTO dto = new SampleDTO();
				// id 값을 설정 
				dto.setId(rset.getString("id"));
				// name 값을 설정
				dto.setName(rset.getString("name"));
				// price 값을 설정 
				dto.setPrice(rset.getInt("price"));
				// 리스트에 저장 
				sampleDTOs.add(dto);
			}			
		} catch (SQLException e) {
			// 접속, SELECT문 발행에 오류가 발생했을 때
			e.printStackTrace();
		}
		
		return sampleDTOs;
	}
}