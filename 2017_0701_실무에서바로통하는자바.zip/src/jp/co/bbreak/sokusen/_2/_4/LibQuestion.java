package jp.co.bbreak.sokusen._2._4;

public class LibQuestion {
	public static void main(String[] args) {
		// 2개의 문자열을 비교합니다.
		String targetStr1 = "첫번째입니다";
		String targetStr2 = "두번째입니다";
		
		if (targetStr1.equals(targetStr2)) {
			System.out.println("두 문자열은 같은 내용입니다");
		} else {
			System.out.println("두 문자열은 다른 내용입니다");
		}
	}
}
