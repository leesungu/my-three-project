package jp.co.bbreak.sokusen._2._1;

import java.math.BigDecimal;

public class PrintReceipt2 {

	public static void main(String[] args) {
		// 내역 데이터 작성
		Detail detail1 = new Detail();
		detail1.setItemName("쌀5㎏");
		detail1.setAmount(new BigDecimal(15000));
		Detail detail2 = new Detail();
		detail2.setItemName("감9개");
		detail2.setAmount(new BigDecimal(9000));

		// 내역 포맷 정의
		String lineBase = "%-10s%10d원";

		// 데이터 가공 
		String result1 = String.format(lineBase, detail1.getItemName(), detail1.getAmount().longValue());
		String result2 = String.format(lineBase, detail2.getItemName(), detail2.getAmount().longValue());
		
		// 내역 출력
		System.out.println(result1);
		System.out.println(result2);
	}

}
