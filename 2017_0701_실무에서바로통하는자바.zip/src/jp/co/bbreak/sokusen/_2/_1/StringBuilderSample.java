package jp.co.bbreak.sokusen._2._1;
public class StringBuilderSample {
	public static void main(String[] args) {
		String text1 = "정말 ";
		String text2 = "감사합니다";
		
		StringBuilder sb = new StringBuilder();
		sb.append(text1);
		sb.append(text2);
		String resultString = sb.toString();
		System.out.println(resultString);
	}
}
