package jp.co.bbreak.sokusen._2._1;
public class TextSample {
	public static void main(String[] args) {
		String text1 = "정말 ";
		String text2 = "감사합니다";
		
		text1 = text1 + text2;
		System.out.println(text1);
	}
}
