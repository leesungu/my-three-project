//package jp.co.bbreak.sokusen._2._1;

import java.math.BigDecimal;

public class Detail {
	// 상품명 
	private String itemName;
	// 금액 
	private BigDecimal amount;
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	
}
