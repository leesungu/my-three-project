package jp.co.bbreak.sokusen._2._1;

import java.text.DecimalFormat;

public class DecimalFormatSample {

	public static void main(String[] args) {
		// DecimalFormatの用意
		DecimalFormat df1 = new DecimalFormat("###,##0");
		DecimalFormat df2 = new DecimalFormat("000,000");
		
		// 入力値の用意
		int input1 = 12;
		int input2 = 1234;
		int input3 = 1234567;
		
		String df1input1 = df1.format(input1);
		String df1input2 = df1.format(input2);
		String df1input3 = df1.format(input3);
		
		String df2input1 = df2.format(input1);
		String df2input2 = df2.format(input2);
		String df2input3 = df2.format(input3);
		
		System.out.println("書式1の結果");
		System.out.println(df1input1);
		System.out.println(df1input2);
		System.out.println(df1input3);
		System.out.println("書式2の結果");
		System.out.println(df2input1);
		System.out.println(df2input2);
		System.out.println(df2input3);
	}

}
