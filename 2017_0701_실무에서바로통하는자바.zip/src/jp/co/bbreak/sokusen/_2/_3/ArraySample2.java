package jp.co.bbreak.sokusen._2._3;

public class ArraySample2 {
	public static void main(String[] args) {
		String[] name = new String[3];
		
		// 값을 저장
		name[0] = "철수";
		name[1] = "영희";
		name[2] = "길동";
		
		// 값을 차례대로 추출 
		for(int i = 0; i < name.length; i++) {
			System.out.println(name[i]);
		}
	}
}