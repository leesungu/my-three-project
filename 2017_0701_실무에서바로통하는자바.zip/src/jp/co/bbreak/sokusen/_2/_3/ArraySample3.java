package jp.co.bbreak.sokusen._2._3;

public class ArraySample3 {
	public static void main(String[] args) {
		String[] name = new String[3];
		
		// 値の格納
		name[0] = "佐藤";
		name[1] = "鈴木";
		name[2] = "田中";
		
		for(String value : name) {
			System.out.println(value);
		}
	}
}