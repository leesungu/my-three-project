package jp.co.bbreak.sokusen._2._3;

public class ArraySample1 {
	public static void main(String[] args) {
		String[] name = new String[3];
		
		// 값을 저장
		name[0] = "철수";
		name[1] = "영희";
		name[2] = "길동";
		
		// 값을 추출 
		System.out.println(name[0]);
		System.out.println(name[1]);
		System.out.println(name[2]);
	}
}