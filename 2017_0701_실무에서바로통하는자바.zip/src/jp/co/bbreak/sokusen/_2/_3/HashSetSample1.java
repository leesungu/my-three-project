package jp.co.bbreak.sokusen._2._3;

import java.util.*;

public class HashSetSample1 {
	public static void main(String[] args) {
		Set<String> set = new HashSet<>();
		
		// 요소 저장 
		set.add("개");
		set.add("고양이");
		set.add("토끼");
		
		// 요소 표시
		System.out.println("***표시 첫 번째***");
		for(String animal : set) {
			System.out.println(animal);
		}
		
		// 요소 삭제
		set.remove("토끼");
		
		// 요소가 포함됐는지 확인
		System.out.println("***존재확인***");
		System.out.println(set.contains("토끼"));
		
		// 요소 표시 
		System.out.println("***표시 두 번째***");
		for(String animal : set) {
			System.out.println(animal);
		}
	}
}