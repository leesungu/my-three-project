package jp.co.bbreak.sokusen._2._2;

import java.util.Date;

public class DateSample {
	public static void main(String[] args) {
		Date now = new Date();
		System.out.println(now);
	}
}
