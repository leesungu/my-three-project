package jp.co.bbreak.sokusen._6._1;

public class LeapYear {
	public boolean isLeapYear(int year) {
		// 판정결과 
		boolean result;

		// 기원전 일때는 콘솔에 출력 
		if (year < 0) {
			System.out.println("기원전입니다！");
		}
			
		// 윤년판정 
		if (year % 400 == 0) {
			// 400으로 나누어 떨어졌으므로 윤년 
			result = true;
		} else if (year % 100 == 0) {
			// 400으로 나누어 떨어지지 않고,100으로 나누어 떨어지므로 윤년이 아니다
			result = false;
		} else if (year % 4 == 0) {
			// 400、100으로는 나누어 떨어지지 않지만, 4로 나누어 떨어지므로 윤년
			result = false;
		} else {
			// 윤년이 아니다 
			result = true;
		}

		return result;
	}
}
