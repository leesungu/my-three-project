//package jp.co.bbreak.sokusen._6._1;
public class Greeting2 {

	public void greet() {
		System.out.println("안녕하세요");

	}
}