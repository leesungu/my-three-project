package jp.co.bbreak.sokusen._6._1;
public class Greeting1 {

	public static void main(String[] args) {
		System.out.println("안녕하세요");
	}
}