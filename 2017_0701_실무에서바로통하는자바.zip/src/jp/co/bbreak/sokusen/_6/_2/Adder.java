package jp.co.bbreak.sokusen._6._2;

public class Adder {
	public int add(int a, int b) {
		return a + b;
	}
}