package jp.co.bbreak.sokusen._6._2;

import static org.junit.Assert.*;

import org.junit.Test;

public class AdderTest {

	@Test
	public void testCase() {
		Adder adder = new Adder();
		int result = adder.add(1, 2);
		
		// 계산결과 비교 
		assertEquals(result, 3);
	}
	
	@Test
	public void testCaseFail() {
		Adder adder = new Adder();
		int result = adder.add(1, 2);
		
		// 계산결과 비교 
		assertEquals(result, 2);
	}
}