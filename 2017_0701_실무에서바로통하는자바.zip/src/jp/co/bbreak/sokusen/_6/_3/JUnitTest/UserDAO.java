package jp.co.bbreak.sokusen._6._3.JUnitTest;

import java.sql.*;

public class UserDAO {
	public User findByUserid(String userid) {
		try {
			Class.forName("org.h2.Driver");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();

		}

		User user = new User();

		// test 데이터베이스에 sa 유저（암호없음）H2DB에 연결
		try(Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");) {
			// USERID를 키로 USER 테이블을 검색 
			PreparedStatement pstmt = con.prepareStatement("SELECT * FROM USER WHERE USERID = ?");
			pstmt.setString(1, userid);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				user.setUserid(rs.getString("USERID"));
				user.setName(rs.getString("NAME"));
				user.setAge(rs.getInt("AGE"));
			}

			rs.close();
			pstmt.close();

		} catch (SQLException e) {
			e.printStackTrace();

		}

		return user;
	}
}