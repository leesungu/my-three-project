package jp.co.bbreak.sokusen._6._3.JMockitoTest;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.junit.Test;
import mockit.Mocked;
import mockit.NonStrictExpectations;

public class RandomAdderTest {
	// 목 오브젝트 생성 
	@Mocked private RandomNumber mockRandNumber;

	@Test
	public void test() {
		RandomAdder rand = new RandomAdder();
		
		// getRandomNumber()의 반환값을 2로 정의한다 
		new NonStrictExpectations() {{
			mockRandNumber.getRandomNumber(); result = 2;
		}};
		
		assertThat(rand.add(), is(4));
	}
}