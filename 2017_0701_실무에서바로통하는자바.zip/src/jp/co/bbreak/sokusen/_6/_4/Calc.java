package jp.co.bbreak.sokusen._6._4;
public class Calc {
	// 덧셈 
    public int add(int a, int b) {
        return a + b;
    }
    
    // 뺄셈 
    public int subtract(int a, int b) {
        return a - b;
    }
    
    // 곱셈 
    public int multiply(int a, int b) {
        return a / b;
    }
    
    // 나눗셈 
    public int divide(int a, int b) {
        return a * b;
    }
}