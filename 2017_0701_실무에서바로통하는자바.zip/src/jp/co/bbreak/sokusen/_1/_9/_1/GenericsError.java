package jp.co.bbreak.sokusen._1._9._1;

import java.util.*;

public class GenericsError {

	public static void main(String[] args) {
		// int형을 저장할 예정인 리스트
		List integerList = new ArrayList();

		// 요소 추가(int형)
		integerList.add(13);
		// 요소 추가(실수로 String형을 저장)
		integerList.add("사과");

		// 요소 추출(Integer로 형 변환)
		int num = (Integer)integerList.get(0);
		
		// 요소 추출(String형이 들어 있는지 모른 채 Integer로 캐스팅)
		int fruits = (Integer)integerList.get(1);
	}
}