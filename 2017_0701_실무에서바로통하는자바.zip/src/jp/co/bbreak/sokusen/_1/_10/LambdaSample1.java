package jp.co.bbreak.sokusen._1._10;

public class LambdaSample1 {
	public static void main(String[] args) {
		// 람다식으로 처리를 구현한다(인수형 지정을 생략한다)
		InterfaceSample1 lambda = (String name) -> {
			return name + "입니다. ";
		};
		
		// 구현한 처리 실행 
		System.out.println(lambda.sampleMethod("길동"));
	}
}