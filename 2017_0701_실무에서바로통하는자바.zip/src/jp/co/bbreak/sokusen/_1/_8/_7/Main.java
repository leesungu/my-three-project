package jp.co.bbreak.sokusen._1._8._7;

public class Main {
	public static void main(String[] args) {
		// 관리직 클래스의 인스턴스 생성 
		Manager manager = new Manager();

		// 응답 메서드 실행
		manager.echo();
	}
}