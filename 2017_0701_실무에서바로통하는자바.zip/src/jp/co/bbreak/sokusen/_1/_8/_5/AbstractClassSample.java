package jp.co.bbreak.sokusen._1._8._5;

//추상 메서드를 가진 클래스를 추상 클래스라고 한다
public abstract class AbstractClassSample {
	// 추상 메서드 
	abstract String sampleMethod(int i);
}