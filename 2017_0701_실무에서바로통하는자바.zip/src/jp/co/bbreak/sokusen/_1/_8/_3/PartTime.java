package jp.co.bbreak.sokusen._1._8._3;

public class PartTime extends Employee {
	// 시프트
	private String shift;

	// 시프트의 게터
	public String getShift() {
			return shift;
	}
		
	// 시프트의 세터
	public void setShift(String shift) {
		this.shift = shift;
	}
}