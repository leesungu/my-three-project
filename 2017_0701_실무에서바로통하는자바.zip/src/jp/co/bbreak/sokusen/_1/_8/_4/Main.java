package jp.co.bbreak.sokusen._1._8._4;

public class Main {
	public static void main(String[] args) {
		Child child = new Child(); 
	}
}