package jp.co.bbreak.sokusen._1._8._8;

public class Employee {
	// 이름
	private String name;
	// 직위
	private String position;

	// 이름 게터 
	public String getName() {
		return name;
	}

	// 직위 게터 
	public String getPosition() {
		return position;
	}

	// 이름 세터 
	public void setName(String name) {
		this.name = name;
	}

	// 직위 세터 
	public void setPosition(String position) {
		this.position = position;
	}

	// 응답 메서드 
	public void echo() {
		System.out.println(this.name+this.position + "입니다.");
	}
}