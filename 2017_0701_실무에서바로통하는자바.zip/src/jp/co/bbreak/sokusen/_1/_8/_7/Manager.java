package jp.co.bbreak.sokusen._1._8._7;

public class Manager {
	// 사원 클래스의 인스턴스를 생성
	Employee employee = new Employee();
	
	// 응답 메서드
	public void echo() {
		// 구현에 사원 클래스의 응답 메서드를 사용한다
		employee.echo();
	}
}