package jp.co.bbreak.sokusen._1._8._5;

public class Manager extends Employee {
	// 응답 메서드 구현
	public void echo() {
		System.out.println("관리직입니다.");
	}
}