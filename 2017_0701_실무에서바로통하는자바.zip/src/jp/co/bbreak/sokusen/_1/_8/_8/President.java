package jp.co.bbreak.sokusen._1._8._8;

public class President extends Employee {
	// 연설 메서드
	public void speech() {
		System.out.println("여러분 힘냅시다!");
	}
	
	public static void main(String[] args) {
		// 관리직 클래스의 인스턴스 생성
		President president = new President();
		
		// 이름 설정(setName의 동작을 알 수 없다)
		president.setName("길동");
		
		// 직위 설정(setPosition의 동작을 알 수 없다)
		president.setPosition("사장");

		// 응답 메서드 실행(echo의 동작을 알 수 없다)
		president.echo();
		
		// 연설 메서드 실행
		president.speech();
	}
}