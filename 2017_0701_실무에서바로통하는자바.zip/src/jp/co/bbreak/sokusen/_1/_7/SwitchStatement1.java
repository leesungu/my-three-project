package jp.co.bbreak.sokusen._1._7;

/**
 * switch문 예제를 실행하고 내용을 확인하는 클래스.
 */
public class SwitchStatement1 {

    /**
     * switch문을 실행하고 내용을 확인합니다.
     * 
     * @param args
     *            커맨드라인 인수. 이번에는 사용되지 않습니다.
     */
    public static void main(String[] args) {
        // 인수의 문자열을 int 값으로 변환
        int value = Integer.valueOf(args[0]);

        // [1] switch文
        System.out.println("■ [1] switch문 -------");
        switch (value) {
        case 0:
            System.out.println("[1] value는 0");
            break;
        case 1:
            System.out.println("[1] value는 1");
            break;
        default:
            System.out.println("[1] value는 0도 1도 아니다");
        }
    }
}