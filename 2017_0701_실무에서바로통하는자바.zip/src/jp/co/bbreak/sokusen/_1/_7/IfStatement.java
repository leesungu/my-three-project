package jp.co.bbreak.sokusen._1._7;

/**
 * if문 예제를 실행하고 내용을 확인하는 클래스.
 */
public class IfStatement {

    /**
     * if문을 실행해, 그 내용을 확인합니다.
     * 
     * @param args
     *            int 값으로 변환할 문자열이 지정된 커맨드라인 인수.
     */
    public static void main(String[] args) {
        // 인수의 문자열을 int 값으로 변환
        int value = Integer.valueOf(args[0]);

        // [1] if문
        if (value == 0) {
            System.out.println("[1] value는 0");
        } else if (value == 1) {
            System.out.println("[1] value는 1");
        } else {
            System.out.println("[1] value는 0도 1도 아니다");
        }
    }
}