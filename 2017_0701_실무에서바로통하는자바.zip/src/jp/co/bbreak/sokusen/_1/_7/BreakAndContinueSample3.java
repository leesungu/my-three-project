package jp.co.bbreak.sokusen._1._7;

/**
 * break문 및 continue문 예제를 실행하고 내용을 확인하는 클래스
 */
public class BreakAndContinueSample3 {

    /**
     * break문 및 continue문을 실행하고 그 내용을 확인합니다.
     * 
     * @param args
     *            커맨드라인 인수. 이번에는 사용하지 않습니다.
     */
    public static void main(String[] args) {
        System.out.println("------- [1] 라벨이 지정된 루프에서 break -------");
        label: for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (j == 1) {
                    System.out.println("j == 1 일 때 label에 대해 break");
                    break label;
                }
                System.out.println("i = " + i + ", j = " + j);
            }
        }

        System.out.println("------- [2] 라벨이 지정된 루프에서 continue -------");
        label: for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (j == 1) {
                    System.out.println("j == 1 일 때 label에 대해 continue");
                    continue label;
                }
                System.out.println("i = " + i + ", j = " + j);
            }
        }
    }
}