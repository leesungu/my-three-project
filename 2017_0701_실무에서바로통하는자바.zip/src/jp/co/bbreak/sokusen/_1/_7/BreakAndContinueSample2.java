package jp.co.bbreak.sokusen._1._7;

/**
 * break문 및 continue문 예제를 실행하고 내용을 확인하는 클래스
 */
public class BreakAndContinueSample2 {

    /**
     * break문 및 continue문을 실행하고 내용을 확인합니다. 
     * 
     * @param args
     *            커맨드라인 인수. 지금은 사용하지 않습니다.
     */
    public static void main(String[] args) {

        System.out.println("------- [1] 루프가 중첩된 경우에 안쪽 루프에서 break -------");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (j == 1) {
                    System.out.println("j == 1 일 때 break");
                    break;
                }
                System.out.println("i = " + i + ", j = " + j);
            }
        }

        System.out.println("------- [2] 루프가 중첩된 경우 안쪽 루프에서 continue -------");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (j == 1) {
                    System.out.println("j == 1 일 때 continue");
                    continue;
                }
                System.out.println("i = " + i + ", j = " + j);
            }
        }

        System.out.println("------- [3] 루프가 중첩된 경우 바깥쪽 루프에서 break -------");
        for (int i = 0; i < 3; i++) {
            if (i == 1) {
                System.out.println("i == 1 일 때 break");
                break;
            }
            for (int j = 0; j < 3; j++) {
                System.out.println("i = " + i + ", j = " + j);
            }
        }

        System.out.println("------- [4] 루프가 중첩된 경우 바깥쪽 루프에서 continue -------");
        for (int i = 0; i < 3; i++) {
            if (i == 1) {
                System.out.println("i == 1 일 때 continue");
                continue;
            }
            for (int j = 0; j < 3; j++) {
                System.out.println("i = " + i + ", j = " + j);
            }
        }
    }
}