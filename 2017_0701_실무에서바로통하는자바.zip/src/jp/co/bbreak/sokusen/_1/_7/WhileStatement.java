package jp.co.bbreak.sokusen._1._7;

/**
 * while문 및 do-while문 예제를 실행하고 내용을 확인하는 클래스.
 */
public class WhileStatement {

    /**
     * while문 및 do-while문을 실행하고 내용을 확인합니다.
     * 
     * @param args
     *            커맨드라인 인수. 이번에는 사용하지 않습니다.
     */
    public static void main(String[] args) {
        // [1] while문 
        System.out.println("------- [1] while문 -------");
        int value = 0;
        while (value < 3) {
            System.out.println("value는 " + value);
            value++;
        }

        // [2] do-while문 
        System.out.println("------- [2] do-while문 -------");
        value = 0;
        do {
            System.out.println("value는 " + value);
            value++;
        } while (value < 3);

        // [3] 조건에 하나도 일치하지 않는 while문
        System.out.println("------- [3] 조건에 하나도 일치하지 않는 while문 -------");
        value = 0;
        while (value < 0) {
            System.out.println("value는 " + value);
            value++;
        }

        // [4] 조건에 하나도 일치하지 않는 do-while문
        System.out.println("------- [4] 조건에 하나도 일치하지 않는 do-while문 -------");
        value = 0;
        do {
            System.out.println("value는 " + value);
            value++;
        } while (value < 0);
    }
}