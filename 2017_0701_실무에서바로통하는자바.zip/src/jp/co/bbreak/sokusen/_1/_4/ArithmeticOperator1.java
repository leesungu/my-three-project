package jp.co.bbreak.sokusen._1._4;

/**
 * 산술연산자를 확인하는 클래스.
 */
public class ArithmeticOperator1 {

    /**
     * 산술연산자를 실행해 내용을 확인합니다.
     * 
     * @param args
     *            커맨드라인 인수. 이번에는 사용되지 않습니다.
     */
    public static void main(String[] args) {
        // [1] 특수한 계산
        int result = 1;
        result += 2;
        System.out.println("[1] result = 1 → result += 2 → result = " + result);

        // [2] 특수한 계산
        System.out.println("[2] result = 1 → ++result");
        result = 1;
        printValue(++result);
        System.out.println("result = " + result);

        // [3] 특수한 계산
        System.out.println("[3] result = 1 → result++");
        result = 1;
        printValue(result++);
        System.out.println("result = " + result);
    }

    /**
     * 전달된 값 value를 표준출력합니다.
     * 
     * @param value
     *            값
     */
    private static void printValue(int value) {
        System.out.println("전달된 값： value = " + value);
    }
}