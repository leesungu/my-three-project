package jp.co.bbreak.sokusen._1._5;

/**
 * Java8에서 부호 없는 Integer와 Long의 한계치일 때의 동작을 확인하는 클래스.
 */
public class OverflowCheck2 {

    /**
     * Java8에서 부호 없는 Integer와 Long의 한계치 예제를 표준출력합니다.
     * 
     * @param args
     *            커맨드라인 인수. 이번에는 사용하지 않습니다.
     */
    public static void main(String[] args) {
        // Java 8뷰토 
        int i = Integer.MAX_VALUE + 1;
        String value = Integer.toUnsignedString(i);
        System.out.println(value);

        i = Integer.MAX_VALUE + Integer.MAX_VALUE + 1;
        value = Integer.toUnsignedString(i);
        System.out.println(value);

        i = i + 1;
        value = Integer.toUnsignedString(i);
        System.out.println(value);

        long l = Long.MAX_VALUE + Long.MAX_VALUE + 1;
        value = Long.toUnsignedString(l);
        System.out.println(value);

        l = l + 1;
        value = Long.toUnsignedString(l);
        System.out.println(value);

    }
}