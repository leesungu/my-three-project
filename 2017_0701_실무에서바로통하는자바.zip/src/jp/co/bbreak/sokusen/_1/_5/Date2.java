import java.util.*;
/**
 * final의 동작을 확인합니다.
 */
public class Date2 {

    /**
     * 참조형 데이터에 final을 붙여도 인스턴스의 값을 변경할 수 있습니다. 
     * 
     * @param args
     *            커맨드라인 인수. 이번에는 사용하지 않습니다.
     */
    public static void main(String[] args) {
        final Date date2 = new Date();
        System.out.println(date2);
        date2.setTime(0);
        System.out.println(date2);
    }
}