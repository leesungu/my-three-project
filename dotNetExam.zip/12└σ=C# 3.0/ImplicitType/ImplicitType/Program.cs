﻿using System;

class CSTest
{
	static void Main()
	{
		var x = 10;
		var y = 5;
		var str = "문자열";

		Console.SetCursorPosition(x, y);
		Console.WriteLine(str);
	}
}
