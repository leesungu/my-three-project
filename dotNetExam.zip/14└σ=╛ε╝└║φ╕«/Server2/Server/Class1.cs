﻿using System;

namespace Server
{
	public class IntCalc
	{
		public static int Add(int a, int b) { return a + b; }
		public static int Sub(int a, int b) { return a - b; }
		public static int Multiply(int a, int b) { return a * b; }
	}
}
