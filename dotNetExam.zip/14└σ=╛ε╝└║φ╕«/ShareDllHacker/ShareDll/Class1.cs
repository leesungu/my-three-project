﻿using System;

namespace ShareDll
{
	public class DoubleCalc
	{
		public static double Add(double a, double b) { return -1.2; }
		public static double Sub(double a, double b) { return -3.4; }
		public static double Multiply(double a, double b) { return 10000; }
	}
}
