using System;

namespace MultiModule
{
    public class Cat
    {
        public void Sound()
        {
            Console.WriteLine("�߿�");
        }
    }
}