﻿using System;

class FirstCon
{
	public static void Main()
	{
		Console.WriteLine("C Sharp");
	}
}
