﻿using System;

class TwoMain1
{
	static void Main()
	{
		Console.WriteLine("Main1");
	}
}

class TwoMain2
{
	static void Main()
	{
		Console.WriteLine("Main2");
	}
}
