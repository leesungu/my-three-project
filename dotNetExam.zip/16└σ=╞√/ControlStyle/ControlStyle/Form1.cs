﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ControlStyle
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
			//SetStyle(ControlStyles.ResizeRedraw, true);
			SetStyle(ControlStyles.ResizeRedraw, false);
		}

		private void Form1_Paint(object sender, PaintEventArgs e)
		{
			e.Graphics.DrawEllipse(Pens.Black, 10, 10, 200, 200);
		}
	}
}
