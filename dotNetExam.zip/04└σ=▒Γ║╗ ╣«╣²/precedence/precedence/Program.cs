﻿using System;

class CSTest
{
	static void Main()
	{
		int a, b = 100000, c = 100000, d = 1000;
		a = b * c / d;
		Console.WriteLine(a);
	}
}
