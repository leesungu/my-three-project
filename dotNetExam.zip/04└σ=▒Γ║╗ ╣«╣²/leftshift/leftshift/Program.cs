﻿using System;

class CSTest
{
	static void Main()
	{
		int i = 2;

		i = i << 4;
		Console.WriteLine(i);
	}
}
