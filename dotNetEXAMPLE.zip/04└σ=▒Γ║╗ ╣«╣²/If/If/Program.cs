﻿using System;

class CSTest
{
	static void Main()
	{
		int i = 3;
		if (i == 3)
		{
			Console.WriteLine("i는 3이다.");
		}
		else
		{
			Console.WriteLine("i는 3이 아니다.");
		}
	}
}
