﻿using System;

class CSTest
{
	static void Main()
	{
		int i = 8, j = 3;
		double k;
		k = i / j;
		Console.WriteLine(k);
	}
}
