﻿class FirstCon
{
	public static void Main()
	{
		System.Console.WriteLine("C Sharp");
	}
}
