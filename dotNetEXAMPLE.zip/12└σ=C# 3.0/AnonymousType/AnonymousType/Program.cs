﻿using System;

class CSTest
{
	static void Main()
	{
		var Lee = new { Name = "이순신", Age = 32 };
		Console.WriteLine("이름 : " + Lee.Name + ", 나이 : " + Lee.Age);
	}
}
