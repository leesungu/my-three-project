﻿using System;

class CSTest
{
	static void Main()
	{
		string str1;
		str1 = "문자열";
		Console.WriteLine(str1);
		string str2 = "C# String";
		Console.WriteLine(str2);
		string str3;
		str3 = str1 + str2;
		Console.WriteLine(str3);
	}
}
