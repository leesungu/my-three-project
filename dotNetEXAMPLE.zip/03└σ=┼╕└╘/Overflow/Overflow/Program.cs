﻿using System;

class CSTest
{
	static void Main()
	{
		byte b;
		b = 255;
		b++;
		Console.WriteLine(b);
	}
}
