using System;

namespace MultiModule
{
    public class Dog
    {
        public void Sound()
        {
            Console.WriteLine("�۸�");
        }
    }
}