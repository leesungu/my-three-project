using System;
using MultiModule;

class CSTest
{
    static void Main()
    {
        Dog D = new Dog();
        D.Sound();
        Cat C = new Cat();
        C.Sound();
    }
}
