﻿using System;

namespace ShareDll
{
	public class DoubleCalc
	{
		public static double Add(double a, double b) { return a + b; }
		public static double Sub(double a, double b) { return a - b; }
	}
}
